package com.example.nimbusnote.data.model

data class Sys(
    val country: String?,
    val sunrise: Long?,
    val sunset: Long?
)
