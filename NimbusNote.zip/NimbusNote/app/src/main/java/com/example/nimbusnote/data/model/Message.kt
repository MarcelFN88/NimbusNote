package com.example.nimbusnote.data.model

data class Message(
    val text: String = "",
    val sender: String = ""

)
