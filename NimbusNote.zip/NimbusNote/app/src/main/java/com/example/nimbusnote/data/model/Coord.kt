package com.example.nimbusnote.data.model

data class Coord(
    val lon: Double?,
    val lat: Double?
)
